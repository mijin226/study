package test1002;

public interface Phone {
	public abstract void powerOn(); // 추상메서드
	void powerOff();
}
