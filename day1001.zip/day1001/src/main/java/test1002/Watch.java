package test1002;

public interface Watch {
	void powerOn();
	void powerOff();
}
