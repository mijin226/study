package test1004;

public interface Watch {
	void powerOn();
	void powerOff();
}
