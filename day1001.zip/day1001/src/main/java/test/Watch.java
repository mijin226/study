package test;

public interface Watch {
	abstract public void powerOn();
	abstract public void powerOff();
}
