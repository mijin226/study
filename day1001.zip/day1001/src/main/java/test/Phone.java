package test;

public interface Phone {
		abstract public void powerOn();	//전원 켜기
		abstract public void powerOff();//전원 끄기
	}
