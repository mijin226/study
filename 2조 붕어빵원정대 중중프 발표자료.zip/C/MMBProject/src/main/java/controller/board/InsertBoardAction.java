package controller.board;

public class InsertBoardAction {

}
